#!/bin/bash
docker-compose up --abort-on-container-exit
