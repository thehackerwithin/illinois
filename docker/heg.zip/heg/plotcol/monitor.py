#!/usr/bin/env python
import os
import time
import numpy as np
import matplotlib.pyplot as plt
from watchdog.observers import Observer
from watchdog.events import LoggingEventHandler

calc_dir = '/work'
import sys
suffix = sys.argv[1]
fdat_name = 'gctas.%s' % suffix
fig_name = '%s.png' % suffix

class MyHandler(LoggingEventHandler):
  def on_modified(self, event):
    if fdat_name in event.src_path:
      savefig()

def savefig():
  fdat = os.path.join(calc_dir, fdat_name)
  data = np.loadtxt(fdat).T
  x = data[0]
  ym = data[1]
  ye = data[2]

  fig, ax = plt.subplots(1, 1)
  ax.errorbar(x, ym, ye, ls='', marker='x')
  fig_loc = os.path.join(calc_dir, fig_name)
  fig.savefig(fig_loc)

if __name__ == '__main__':
  observer = Observer()
  event_handler = MyHandler()
  observer.schedule(event_handler, calc_dir, recursive=False)
  observer.start()

  try:
    while True:
      time.sleep(3)
  except KeyboardInterrupt:
    observer.stop()
  observer.join()
# end __main__
